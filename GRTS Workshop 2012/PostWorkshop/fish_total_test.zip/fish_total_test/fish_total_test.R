

library(spsurvey)

# Read the attribute table from the shapefile

att <- read.dbf("luck-ash")
cat("The initial six lines in the attribute data frame follow:\n\n")
print(head(att))
names(att)
abundance<-rnorm(nrow(att),100,0)
total.abund <- sum(abundance)
total.length <- sum(att$length)

density <- abundance/att$length

att<-cbind(att,abundance, density)

# Equal probability GRTS survey design

# Create the design list

Equaldsgn <- list(None=list(panel=c(Panel_1=10), seltype="Equal"))

# Create the GRTS survey design

Equalsites <- grts(design=Equaldsgn,
                   DesignID="LuckEQ",
                   type.frame="linear",
                   src.frame="shapefile",
                   in.shape="luck-ash",
                   att.frame=att,
                   prjfilename="luck-ash",
                   out.shape="Luck.EqualSites")

# Convert grts output to dataframe
y <- data.frame(Equalsites)

# Print the initial six lines of the survey design

cat("\nThe initial six lines of the survey design follow:\n\n")
print(head(Equalsites@data))
cat("\n")

# Print the survey design summary

cat("\nThe survey design summary follows:\n\n")
print(dsgnsum(Equalsites))


###############################################################################
# ANALYSIS FUNCTIONS
# These functions estimate the mean response and variance for the whole population, 
# and any subpopulations specified. This is useful for evaluating "status"

# Create the sites data frame
mysites <- data.frame(siteID=y$siteID,Use=y$panel != "OverSamp")

# Define subpopulations
mysubpop <- data.frame(siteID=y$siteID, all.sites=rep("AllSites",length(y$siteID)))

# Define popsize
# mypopsize <- list(sum(Equalsites$wgt))

# Create the design data frame, which identifies the stratum code, weight,
# x-coordinate, and y-coordinate for each site ID
mydesign <- data.frame(siteID=y$siteID,wgt=y$wgt,xcoord=y$xcoord,ycoord=y$ycoord) 

# Create the data.cat data frame
mydata.cont <- data.frame(siteID=y$siteID, abundance = y$abundance, density=y$density) 

# Store analysis results                                 
results <- cont.analysis(sites=mysites, subpop=mysubpop, design=mydesign, data.cont=mydata.cont, total=TRUE)

# true total abundance
total.abund

# true mean abundance
mean.abundance <- mean(att$abundance)

# true mean density
mean.density <- total.abund/total.length



